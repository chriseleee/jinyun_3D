//
//  02_第三个人.c
//  Day11
//
//  Created by tarena on 15/7/13.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#include "02_第三个人.h"

void output(int *a, int size, int max)
{
    for (int i = 0; i< 10; i++)
    {
        printf("%d ", a[i]);
    }
    printf("\n");
    printf("max=%d\n", max);
}

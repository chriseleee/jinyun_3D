//
//  02_第三个人.h
//  Day11
//
//  Created by tarena on 15/7/13.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#ifndef 第三个人
#define 第三个人

#include <stdio.h>
void output(int *a, int size, int max);

#endif /* defined(__Day11___2_______) */

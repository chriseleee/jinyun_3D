//
//  02_第一个人.h
//  Day11
//
//  Created by tarena on 15/7/13.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#ifndef 第一个人
#define 第一个人

#include <stdio.h>
void input(int *a, int size);

#endif 

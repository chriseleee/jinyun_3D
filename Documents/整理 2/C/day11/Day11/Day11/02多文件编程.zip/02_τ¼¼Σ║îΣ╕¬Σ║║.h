//
//  02_第二个人.h
//  Day11
//
//  Created by tarena on 15/7/13.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#ifndef 第二个人
#define 第二个人

#include <stdio.h>
int maxInArray(int *a, int size);

#endif /* defined(__Day11___2_______) */

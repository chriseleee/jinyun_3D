//
//  Party.h
//  GDataXMLSample
//
//  Created by iC on 2/26/13.
//  Copyright (c) 2013 iC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Party : NSObject
@property (strong, nonatomic) NSMutableArray *players;
@end

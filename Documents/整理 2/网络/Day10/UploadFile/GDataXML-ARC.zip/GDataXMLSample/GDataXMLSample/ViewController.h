//
//  ViewController.h
//  GDataXMLSample
//
//  Created by iC on 2/26/13.
//  Copyright (c) 2013 iC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
